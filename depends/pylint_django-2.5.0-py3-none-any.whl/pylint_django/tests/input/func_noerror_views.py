"""
Checks that Pylint does not complain when using function based views.
"""
#  pylint: disable=missing-docstring


def empty_view(request):
    pass
